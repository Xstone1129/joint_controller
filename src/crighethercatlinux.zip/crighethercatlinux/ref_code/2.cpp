#include <igh_driver_cr.h> 

/*****************************************************************************/
namespace {

template <typename T>
bool ODread_impl(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, T* objectValue)
{
	uint32_t abort_code = 0;
	size_t result_size = 0;
	uint8_t objectBytes[sizeof(T)] = {0};
	uint8_t retVal = ecrt_master_sdo_upload(
		master,
		slavePos,
		index,
		subIndex,
		objectBytes,
		sizeof(objectBytes),
		&result_size,
		&abort_code);

	if (retVal || result_size < sizeof(T)) {
		printf("OD read fail index:0x%04x sub:0x%02x abort:0x%08x size:%zu\n",
			index,
			subIndex,
			abort_code,
			result_size);
		return false;
	}

	memcpy(objectValue, objectBytes, sizeof(T));
	return true;
}

} // namespace

/*****************************************************************************/
bool ODwrite(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, uint8_t objectValue)
{
	uint32_t abort_code;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, &objectValue, sizeof(objectValue), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("OD write fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("OD write successful\n");
		return true;
	}
}

bool ODwrite_s32(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, int32_t objectValue)
{
	return ODwrite_u32(master, slavePos, index, subIndex, static_cast<uint32_t>(objectValue));
}

bool ODread_u16(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, uint16_t* objectValue)
{
	return ODread_impl(master, slavePos, index, subIndex, objectValue);
}

bool ODread_u32(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, uint32_t* objectValue)
{
	return ODread_impl(master, slavePos, index, subIndex, objectValue);
}

bool ODread_s32(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, int32_t* objectValue)
{
	return ODread_impl(master, slavePos, index, subIndex, objectValue);
}

bool ODwrite_u16(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, uint16_t objectValue)
{
	uint32_t abort_code;
	uint8_t objectBytes[2];
	objectBytes[0] = objectValue & 0xFF;
	objectBytes[1] = (objectValue >> 8) & 0xFF;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, objectBytes, sizeof(objectBytes), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("OD write fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("OD write successful\n");
		return true;
	}
}

bool ODwrite_u32(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex, uint32_t objectValue)
{
	uint32_t abort_code;
	uint8_t objectBytes[4];
	objectBytes[0] = objectValue & 0xFF;
	objectBytes[1] = (objectValue >> 8) & 0xFF;
	objectBytes[2] = (objectValue >> 16) & 0xFF;
	objectBytes[3] = (objectValue >> 24) & 0xFF;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, objectBytes, sizeof(objectBytes), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("OD write fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("OD write successful\n");
		return true;
	}
}

bool ODwrite_607F(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex)
{
	uint32_t abort_code;
	uint8_t objectValue[2];
	objectValue[0] = 0x40;
	objectValue[1] = 0x9C;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, objectValue, sizeof(objectValue), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("ODwrite_607F fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("ODwrite_607F successful\n");
		return true;
	}
}
bool ODwrite_6080(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex)
{
	uint32_t abort_code;
	uint8_t objectValue[2];
	objectValue[0] = 0x40;
	objectValue[1] = 0x9C;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, objectValue, sizeof(objectValue), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("ODwrite_6080 fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("ODwrite_6080 successful\n");
		return true;
	}
}

bool ODwrite_6065(ec_master_t* master, uint16_t slavePos, uint16_t index, uint8_t subIndex)
{
	uint32_t abort_code;
	uint8_t objectValue[2];
	objectValue[0] = 0x40;
	objectValue[1] = 0x9C;
	/* Blocks until a reponse is received */
	uint8_t retVal = ecrt_master_sdo_download(master, slavePos, index, subIndex, objectValue, sizeof(objectValue), &abort_code);
	/* retVal != 0: Failure */
	if (retVal) {
		printf("ODwrite_6065 fail:0X%08x\n",abort_code);
		return false;
	} else{
		printf("ODwrite_6065 successful\n");
		return true;
	}
}

namespace {

void LogZeroInitSdoStart(
	const char* profile_name,
	uint16_t slavePos,
	uint16_t index,
	uint8_t subIndex,
	unsigned int bit_width,
	uint32_t value)
{
	printf(
		"zero_init profile:%s slave:%u sdo 0x%04x:%02x width:%u value:0x%08x begin\n",
		profile_name,
		slavePos,
		index,
		subIndex,
		bit_width,
		value);
}

void LogZeroInitSdoResult(
	const char* profile_name,
	uint16_t slavePos,
	uint16_t index,
	uint8_t subIndex,
	bool success)
{
	printf(
		"zero_init profile:%s slave:%u sdo 0x%04x:%02x result:%s\n",
		profile_name,
		slavePos,
		index,
		subIndex,
		success ? "success" : "fail");
}

} // namespace

bool initDrive_zero(ec_master_t* master, uint16_t slavePos , uint8_t axismode, const char* profile_name)
{
	LogZeroInitSdoStart(profile_name, slavePos, 0x6060, 0x00, 8U, axismode);
	const bool mode_ok = ODwrite(master, slavePos, 0x6060, 0x00, axismode);
	LogZeroInitSdoResult(profile_name, slavePos, 0x6060, 0x00, mode_ok);

	LogZeroInitSdoStart(profile_name, slavePos, 0x6040, 0x00, 8U, 0x80U);
	const bool reset_ok = ODwrite(master, slavePos, 0x6040, 0x00, 0x80);
	LogZeroInitSdoResult(profile_name, slavePos, 0x6040, 0x00, reset_ok);

	return mode_ok && reset_ok;
}

bool initDrive_hcfa(ec_master_t* master, uint16_t slavePos , uint8_t axismode)
{

	/* Mode of operation, CSV */
	const bool mode_ok = ODwrite(master, slavePos, 0x6060, 0x00, axismode);  // 0x09 for CSV mode
	const bool v1_ok = ODwrite_607F(master, slavePos, 0x607F, 0x00);  // 0x09 for CSV mode
	const bool v2_ok = ODwrite_6080(master, slavePos, 0x6080, 0x00);  // 0x09 for CSV mode
	const bool v3_ok = ODwrite_6065(master, slavePos, 0x6065, 0x00);  // 0x09 for CSV mode
	/* Reset alarm */
	const bool reset_ok = ODwrite(master, slavePos, 0x6040, 0x00, 0x80);
	return mode_ok && v1_ok && v2_ok && v3_ok && reset_ok;
}

bool init_chage_Drive(ec_master_t* master, uint16_t slavePos , uint8_t axismode)
{

	/* Mode of operation, CSV */
	const bool mode_ok = ODwrite(master, slavePos, 0x6060, 0x00, axismode);  // 0x09 for CSV mode
	/* Reset alarm */
	const bool reset_ok = ODwrite(master, slavePos, 0x6040, 0x00, 0x80);
	return mode_ok && reset_ok;
}
