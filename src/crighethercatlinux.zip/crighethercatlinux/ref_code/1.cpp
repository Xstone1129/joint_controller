#include "igh_driver_internal.h"

#include <algorithm>
#include <cstring>

namespace igh_driver_internal {

namespace {

/* 兼容 zero 风格驱动的 PDO 定义。旧 zero 和新 EYOU 仅编码器对象号不同。 */
ec_pdo_entry_info_t zero_legacy_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x607a, 0x00, 32},
    {0x60FF, 0x00, 32},
    {0x6071, 0x00, 16},
    {0x6060, 0x00, 16},
    {0x6041, 0x00, 16},
    {0x6064, 0x00, 32},
    {0x606c, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x6061, 0x00, 16},
};

ec_pdo_info_t zero_legacy_pdos[] = {
    {0x1600, 5, zero_legacy_pdo_entries + 0},
    {0x1a00, 5, zero_legacy_pdo_entries + 5},
};

ec_sync_info_t zero_legacy_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, zero_legacy_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, zero_legacy_pdos + 1, EC_WD_DISABLE},
    {0xFF},
};

ec_pdo_entry_info_t zero_eyou_pdo_entries[] = {
    {0x607a, 0x00, 32},
    {0x60FE, 0x00, 32},
    {0x6071, 0x00, 16},
    {0x6060, 0x00, 8},
    {0x0000, 0x00, 8},
    {0x6041, 0x00, 16},
    {0x6064, 0x00, 32},
    {0x606c, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x202A, 0x00, 32},
    {0x202B, 0x00, 32},
    {0x6061, 0x00, 8},
    {0x0000, 0x00, 8},
};

ec_pdo_info_t zero_eyou_pdos[] = {
    {0x1600, 6, zero_eyou_pdo_entries + 0},
    {0x1a00, 8, zero_eyou_pdo_entries + 6},
};

ec_sync_info_t zero_eyou_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, zero_eyou_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, zero_eyou_pdos + 1, EC_WD_DISABLE},
    {0xFF},
};

/* PH 驱动 PDO 必须保持 16-bit 对齐，否则配置会失败。 */
ec_pdo_entry_info_t ph_pdo_entries[] = {
    {0x6040, 0x00, 16},
    {0x607A, 0x00, 32},
    {0x60FF, 0x00, 32},
    {0x6071, 0x00, 16},
    {0x6060, 0x00, 8},
    {0x0000, 0x00, 8},
    {0x6041, 0x00, 16},
    {0x6064, 0x00, 32},
    {0x606C, 0x00, 32},
    {0x6077, 0x00, 16},
    {0x6061, 0x00, 8},
    {0x603F, 0x00, 16},
    {0x0000, 0x00, 8},
};

ec_pdo_info_t ph_pdos[] = {
    {0x1600, 6, ph_pdo_entries + 0},
    {0x1A00, 7, ph_pdo_entries + 6},
};

ec_sync_info_t ph_syncs[] = {
    {0, EC_DIR_OUTPUT, 0, nullptr, EC_WD_DISABLE},
    {1, EC_DIR_INPUT, 0, nullptr, EC_WD_DISABLE},
    {2, EC_DIR_OUTPUT, 1, ph_pdos + 0, EC_WD_ENABLE},
    {3, EC_DIR_INPUT, 1, ph_pdos + 1, EC_WD_DISABLE},
    {0xFF},
};


constexpr uint32_t kEyouPhVendorId = 0x00001097;
constexpr uint32_t kEyouPhProductCode = 0x00002406;
constexpr uint16_t kEyouPhDcAssignActivate = 0x0300;
constexpr uint32_t kEyouZeroPh17ProductCode = 0x00221701U;
constexpr uint32_t kEyouZeroPh20ProductCode = 0x00222001U;
constexpr uint32_t kEyouZeroPh25ProductCode = 0x00222501U;
constexpr uint8_t kMixedAxisCount = 7;
constexpr std::array<DriveKind, kMixedAxisCount> kPhysicalDriveKinds{{
    DriveKind::EyouPhV145,
    DriveKind::ZeroLegacy,
    DriveKind::EyouPhV145,
    DriveKind::EyouPhV145,
    DriveKind::EyouPhV145,
    DriveKind::ZeroLegacy,
    DriveKind::ZeroLegacy,
}};
constexpr std::array<uint8_t, 4> kModeSwitchAxes{{0, 2, 3, 4}};
constexpr uint8_t kModeSwitchAxisCount = static_cast<uint8_t>(kModeSwitchAxes.size());
constexpr uint8_t kModeSwitchLogAxisFirst = kModeSwitchAxes[0];
constexpr uint8_t kModeSwitchLogAxisMiddle = kModeSwitchAxes[1];
constexpr uint8_t kModeSwitchLogAxisLast = kModeSwitchAxes[3];
constexpr int32_t kStandstillVelocityThreshold = 100;
constexpr uint32_t kStandstillRequiredCycles = FREQUENCY / 2;
constexpr uint32_t kModeDwellCycles = FREQUENCY * 10;
constexpr uint32_t kAxisErrorLogPeriodCycles = FREQUENCY / 10;
constexpr uint32_t kAxisErrorPollPeriodCycles = 4;
constexpr uint32_t kAxisErrorRequestTimeoutMs = 50;
constexpr uint32_t kRuntimeSnapshotPeriodCycles = FREQUENCY * 3;
constexpr uint32_t kCspReentryTakeoverStableCycles = FREQUENCY / 5;

constexpr ZeroCompatibleProfile kZeroLegacyProfile{
    "ZeroLegacy",
    DriveKind::ZeroLegacy,
    zero_vendor_id,
    zero_product_code,
    0,
    0,
    zero_legacy_syncs,
    true,
};

constexpr ZeroCompatibleProfile kZeroEyouProfile{
    "EyouZeroCompatible",
    DriveKind::ZeroEyou,
    kEyouPhVendorId,
    0,
    0x202A,
    0x202B,
    zero_eyou_syncs,
    false,
};

constexpr std::array<ZeroCompatibleProfile, 2> kZeroCompatibleProfiles{{
    kZeroLegacyProfile,
    kZeroEyouProfile,
}};

enum class ModeSwitchTestState : uint8_t {
    BootHoldCsp,
    EnableAxis,
    WaitStandstillInCsp,
    CspDwell,
    RequestCst,
    WaitCstAck,
    CstDwell,
    RequestCsp,
    WaitCspAck,
    FaultHold,
};

struct ModeSwitchTestContext {
    ModeSwitchTestState state = ModeSwitchTestState::BootHoldCsp;
    uint8_t requested_mode = AXIS_MODE_CSP;
    int32_t hold_position = 0;
    uint32_t standstill_cycles = 0;
    uint32_t dwell_cycles = 0;
    bool wait_standstill_announced = false;
};

ModeSwitchTestContext mode_switch_test_ctx{};
std::array<int32_t, kMaxZeroAxisCount> hold_positions{};
std::array<bool, kMaxZeroAxisCount> hold_position_initialized{};
std::array<bool, 2> arm_group_prepared_this_cycle{{false, false}};
std::array<uint8_t, 2> arm_group_requested_mode{{AXIS_MODE_CSP, AXIS_MODE_CSP}};
std::array<uint8_t, 2> arm_group_previous_mode{{AXIS_MODE_CSP, AXIS_MODE_CSP}};
std::array<bool, 2> arm_group_hold_active{{false, false}};
std::array<bool, 2> arm_group_csp_reentry_hold_active{{false, false}};
std::array<uint32_t, 2> arm_group_csp_reentry_ready_cycles{{0, 0}};
std::array<uint32_t, 2> arm_group_csp_reentry_takeover_cycles{{0, 0}};
std::array<uint8_t, kAxisStateSlotCount> zero_previous_mode{};
std::array<bool, kAxisStateSlotCount> zero_csp_reentry_hold_active{};
std::array<uint32_t, kAxisStateSlotCount> zero_csp_reentry_ready_cycles{};
std::array<uint32_t, kAxisStateSlotCount> zero_csp_reentry_takeover_cycles{};
std::array<bool, kAxisStateSlotCount> enable_sequence_allowed_slots{};
uint8_t enable_sequence_cursor = 0;
bool enable_sequence_active = false;
bool fault_inhibit_active = false;

inline int32_t AbsI32(int32_t value)
{
    return value >= 0 ? value : -value;
}

bool IsModeSwitchAxis(uint8_t axis_index)
{
    return std::find(kModeSwitchAxes.begin(), kModeSwitchAxes.end(), axis_index) !=
           kModeSwitchAxes.end();
}

bool IsAxisInActiveRange(uint8_t axis_index)
{
    return axis_index < kMixedAxisCount;
}

bool IsEyouPhDrive(const MasterContext& ctx, uint8_t axis_index)
{
    return IsValidAxisIndex(axis_index) && ctx.axis_drive_kinds[axis_index] == DriveKind::EyouPhV145;
}

bool IsZeroDrive(const MasterContext& ctx, uint8_t axis_index)
{
    return IsValidAxisIndex(axis_index) &&
           IsZeroCompatibleDriveKind(ctx.axis_drive_kinds[axis_index]);
}

bool IsZeroLegacyDrive(const MasterContext& ctx, uint8_t axis_index)
{
    return IsValidAxisIndex(axis_index) && ctx.axis_drive_kinds[axis_index] == DriveKind::ZeroLegacy;
}

const ZeroCompatibleProfile* MatchZeroCompatibleProfile(const ec_slave_info_t& slave_info)
{
    if (IsZeroVendorCompatible(slave_info.vendor_id) &&
        slave_info.product_code == zero_product_code) {
        return &kZeroLegacyProfile;
    }

    if (slave_info.vendor_id == kEyouPhVendorId &&
        (slave_info.product_code == kEyouZeroPh17ProductCode ||
         slave_info.product_code == kEyouZeroPh20ProductCode ||
         slave_info.product_code == kEyouZeroPh25ProductCode)) {
        return &kZeroEyouProfile;
    }

    return nullptr;
}

const ec_sync_info_t* GetDriveSyncs(const MasterContext& ctx, uint16_t slave_pos)
{
    const DriveKind drive_kind = ctx.slave_drive_kinds[slave_pos];
    if (drive_kind == DriveKind::EyouPhV145) {
        return ph_syncs;
    }

    const ZeroCompatibleProfile* profile = ctx.slave_zero_profiles[slave_pos];
    return profile != nullptr ? profile->syncs : nullptr;
}

void PrintAxisBindingSummary(const MasterContext& ctx)
{
    printf("%s axis binding summary begin\n", GetMasterName(ctx));
    for (uint8_t axis_index = 0; axis_index < kMixedAxisCount; ++axis_index) {
        const DriveKind drive_kind = ctx.axis_drive_kinds[axis_index];
        const ec_slave_config_t* drive_config = ctx.drive_configs[axis_index];
        printf(
            "%s axis:%u binding:%s configured:%s\n",
            GetMasterName(ctx),
            axis_index,
            GetDriveKindName(drive_kind),
            drive_config != nullptr ? "yes" : "no");
    }
    printf("%s axis binding summary end\n", GetMasterName(ctx));
}

bool ResolveAxisIndexFromAliasOrPosition(
    const MasterContext& ctx,
    uint16_t slave_pos,
    const ec_slave_info_t& slave_info,
    uint8_t& axis_index,
    bool& uses_alias_selection)
{
    uses_alias_selection = false;
    if (TryResolveAxisIndex(slave_info.alias, axis_index) && IsAxisInActiveRange(axis_index)) {
        uses_alias_selection = true;
        return true;
    }

    if (slave_pos < kMixedAxisCount) {
        axis_index = static_cast<uint8_t>(slave_pos);
        return true;
    }

    axis_index = kInvalidAxisIndex;
    return false;
}

uint8_t NormalizeArmGroupMode(uint8_t requested_mode)
{
    switch (requested_mode) {
    case AXIS_MODE_CST:
        return AXIS_MODE_CST;
    case AXIS_MODE_CSV:
        return AXIS_MODE_CSV;
    case AXIS_MODE_CSP:
    default:
        return AXIS_MODE_CSP;
    }
}

const char* GetAxisModeName(uint8_t mode)
{
    switch (mode) {
    case AXIS_MODE_CSP:
        return "CSP";
    case AXIS_MODE_CST:
        return "CST";
    case AXIS_MODE_CSV:
        return "CSV";
    default:
        return "UNKNOWN";
    }
}

uint8_t GetMasterContextIndex(const MasterContext& ctx)
{
    return ctx.master_index == 0 ? 0 : 1;
}

void SnapshotModeSwitchAxisPositions(const MasterContext& ctx, const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);
        hold_positions[slot] = cache.act_pos[slot];
        hold_position_initialized[slot] = true;
    }
}

void ClearArmGroupHoldContext(const MasterContext& ctx)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        hold_position_initialized[GetSharedAxisSlot(ctx, axis_index)] = false;
    }
    arm_group_hold_active[GetMasterContextIndex(ctx)] = false;
}

void ResetArmGroupCspReentryHold(uint8_t ctx_index)
{
    arm_group_csp_reentry_hold_active[ctx_index] = false;
    arm_group_csp_reentry_ready_cycles[ctx_index] = 0;
    arm_group_csp_reentry_takeover_cycles[ctx_index] = 0;
}

void ResetZeroCspReentryHold(uint8_t slot)
{
    zero_csp_reentry_hold_active[slot] = false;
    zero_csp_reentry_ready_cycles[slot] = 0;
    zero_csp_reentry_takeover_cycles[slot] = 0;
}

bool IsAxisStandstill(const CycleCache& cache, uint8_t axis_index)
{
    return IsValidAxisIndex(axis_index) &&
           AbsI32(cache.act_vel[axis_index]) < kStandstillVelocityThreshold;
}

bool AreAllModeSwitchAxesOperationEnabled(const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (cache.state[axis_index] != STATE_OPERATION_ENABLED) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesOperationEnabled(const MasterContext& ctx, const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsEyouPhDrive(ctx, axis_index)) {
            continue;
        }

        if (cache.state[GetSharedAxisSlot(ctx, axis_index)] != STATE_OPERATION_ENABLED) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesInMode(const CycleCache& cache, uint8_t mode)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (cache.mode_word[axis_index] != mode) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesInMode(const MasterContext& ctx, const CycleCache& cache, uint8_t mode)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsEyouPhDrive(ctx, axis_index)) {
            continue;
        }

        if (cache.mode_word[GetSharedAxisSlot(ctx, axis_index)] != mode) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesStandstill(const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsAxisStandstill(cache, axis_index)) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesStandstill(const MasterContext& ctx, const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsEyouPhDrive(ctx, axis_index)) {
            continue;
        }

        if (!IsAxisStandstill(cache, GetSharedAxisSlot(ctx, axis_index))) {
            return false;
        }
    }

    return true;
}

bool AreAllModeSwitchAxesDesiredPositionsWithinWindow(const MasterContext& ctx)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsEyouPhDrive(ctx, axis_index)) {
            continue;
        }

        const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);
        if (!hold_position_initialized[slot]) {
            return false;
        }

        const int32_t diff =
            ec_shm_desire_axis_data.axis_ctr[slot].axis_position - hold_positions[slot];
        if (AbsI32(diff) > CSP_REENTRY_COMMAND_WINDOW) {
            return false;
        }
    }

    return true;
}

bool IsZeroDesiredPositionWithinWindow(uint8_t slot)
{
    if (!hold_position_initialized[slot]) {
        return false;
    }

    const int32_t diff = ec_shm_desire_axis_data.axis_ctr[slot].axis_position - hold_positions[slot];
    return AbsI32(diff) <= CSP_REENTRY_COMMAND_WINDOW;
}

void UpdateArmGroupCspReentryHoldState(const MasterContext& ctx, const CycleCache& cache)
{
    const uint8_t ctx_index = GetMasterContextIndex(ctx);
    if (!arm_group_csp_reentry_hold_active[ctx_index]) {
        return;
    }

    if (AreAllModeSwitchAxesInMode(ctx, cache, AXIS_MODE_CSP) &&
        AreAllModeSwitchAxesOperationEnabled(ctx, cache) &&
        AreAllModeSwitchAxesStandstill(ctx, cache)) {
        ++arm_group_csp_reentry_ready_cycles[ctx_index];
    } else {
        arm_group_csp_reentry_ready_cycles[ctx_index] = 0;
        arm_group_csp_reentry_takeover_cycles[ctx_index] = 0;
        return;
    }

    if (arm_group_csp_reentry_ready_cycles[ctx_index] < kStandstillRequiredCycles) {
        arm_group_csp_reentry_takeover_cycles[ctx_index] = 0;
        return;
    }

    if (AreAllModeSwitchAxesDesiredPositionsWithinWindow(ctx)) {
        ++arm_group_csp_reentry_takeover_cycles[ctx_index];
    } else {
        arm_group_csp_reentry_takeover_cycles[ctx_index] = 0;
    }

    if (arm_group_csp_reentry_takeover_cycles[ctx_index] >= kCspReentryTakeoverStableCycles) {
        ResetArmGroupCspReentryHold(ctx_index);
        printf("%s arm_group_mode_switch: CSP reentry takeover accepted, release position hold\n",
               GetMasterName(ctx));
    }
}

void UpdateZeroCspReentryHoldState(uint8_t slot, const CycleCache& cache)
{
    if (!zero_csp_reentry_hold_active[slot]) {
        return;
    }

    if (cache.mode_word[slot] == AXIS_MODE_CSP &&
        cache.state[slot] == STATE_OPERATION_ENABLED &&
        IsAxisStandstill(cache, slot)) {
        ++zero_csp_reentry_ready_cycles[slot];
    } else {
        zero_csp_reentry_ready_cycles[slot] = 0;
        zero_csp_reentry_takeover_cycles[slot] = 0;
        return;
    }

    if (zero_csp_reentry_ready_cycles[slot] < kStandstillRequiredCycles) {
        zero_csp_reentry_takeover_cycles[slot] = 0;
        return;
    }

    if (IsZeroDesiredPositionWithinWindow(slot)) {
        ++zero_csp_reentry_takeover_cycles[slot];
    } else {
        zero_csp_reentry_takeover_cycles[slot] = 0;
    }

    if (zero_csp_reentry_takeover_cycles[slot] >= kCspReentryTakeoverStableCycles) {
        ResetZeroCspReentryHold(slot);
        printf("zero_axis slot:%u CSP reentry takeover accepted, release position hold\n", slot);
    }
}

bool AreAllModeSwitchAxesModeSuccess()
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (axis_mode_states[axis_index] != AXIS_MODE_SUCCESS) {
            return false;
        }
    }

    return true;
}

bool HasAnyModeSwitchAxisFault(const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        if ((cache.state[axis_index] == STATE_FAULT) || ((cache.status_word[axis_index] & AXIS_STATUES_ERR) != 0)) {
            return true;
        }
    }

    return false;
}

const char* GetModeSwitchStateName(ModeSwitchTestState state)
{
    switch (state) {
    case ModeSwitchTestState::BootHoldCsp:
        return "BootHoldCsp";
    case ModeSwitchTestState::EnableAxis:
        return "EnableAxis";
    case ModeSwitchTestState::WaitStandstillInCsp:
        return "WaitStandstillInCsp";
    case ModeSwitchTestState::CspDwell:
        return "CspDwell";
    case ModeSwitchTestState::RequestCst:
        return "RequestCst";
    case ModeSwitchTestState::WaitCstAck:
        return "WaitCstAck";
    case ModeSwitchTestState::CstDwell:
        return "CstDwell";
    case ModeSwitchTestState::RequestCsp:
        return "RequestCsp";
    case ModeSwitchTestState::WaitCspAck:
        return "WaitCspAck";
    case ModeSwitchTestState::FaultHold:
        return "FaultHold";
    }

    return "Unknown";
}

void LogModeSwitchEvent(const char* event, const CycleCache& cache)
{
    uint32_t enabled_count = 0;
    uint32_t requested_mode_count = 0;
    int32_t max_abs_velocity = 0;

    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (cache.state[axis_index] == STATE_OPERATION_ENABLED) {
            ++enabled_count;
        }
        if (cache.mode_word[axis_index] == mode_switch_test_ctx.requested_mode) {
            ++requested_mode_count;
        }
        max_abs_velocity = std::max(max_abs_velocity, AbsI32(cache.act_vel[axis_index]));
    }

    printf(
        "axes:[0-%u] event:%s state:%s req_mode:0x%02x enabled:%u/%u in_req:%u/%u max_abs_vel:%d "
        "samples:a%u{mode:0x%02x pos:%d vel:%d} a%u{mode:0x%02x pos:%d vel:%d} a%u{mode:0x%02x pos:%d vel:%d}\n",
        static_cast<unsigned int>(kModeSwitchLogAxisLast),
        event,
        GetModeSwitchStateName(mode_switch_test_ctx.state),
        mode_switch_test_ctx.requested_mode,
        enabled_count,
        static_cast<unsigned int>(kModeSwitchAxisCount),
        requested_mode_count,
        static_cast<unsigned int>(kModeSwitchAxisCount),
        max_abs_velocity,
        static_cast<unsigned int>(kModeSwitchLogAxisFirst),
        cache.mode_word[kModeSwitchLogAxisFirst],
        cache.act_pos[kModeSwitchLogAxisFirst],
        cache.act_vel[kModeSwitchLogAxisFirst],
        static_cast<unsigned int>(kModeSwitchLogAxisMiddle),
        cache.mode_word[kModeSwitchLogAxisMiddle],
        cache.act_pos[kModeSwitchLogAxisMiddle],
        cache.act_vel[kModeSwitchLogAxisMiddle],
        static_cast<unsigned int>(kModeSwitchLogAxisLast),
        cache.mode_word[kModeSwitchLogAxisLast],
        cache.act_pos[kModeSwitchLogAxisLast],
        cache.act_vel[kModeSwitchLogAxisLast]);
}

void LogStandstillWaitOnce(const char* context, const CycleCache& cache)
{
    if (mode_switch_test_ctx.wait_standstill_announced) {
        return;
    }

    mode_switch_test_ctx.wait_standstill_announced = true;
    printf(
        "axes:[0-13] event:等待静止 context:%s sample_vel:[%d,%d,%d] threshold:%d\n",
        context,
        cache.act_vel[kModeSwitchLogAxisFirst],
        cache.act_vel[kModeSwitchLogAxisMiddle],
        cache.act_vel[kModeSwitchLogAxisLast],
        kStandstillVelocityThreshold);
}

void ResetStandstillTracking()
{
    mode_switch_test_ctx.standstill_cycles = 0;
    mode_switch_test_ctx.wait_standstill_announced = false;
}

bool HasAnyAxisErrorCode(const CycleCache& cache)
{
    for (std::size_t slot = 0; slot < cache.axis_error_code.size(); ++slot) {
        if (cache.axis_error_code[slot] != 0) {
            return true;
        }
    }

    return false;
}

void PrintAxisErrorCodeLog(const CycleCache& cache)
{
    bool found_error = false;
    printf("axis_error_codes:");

    for (std::size_t slot = 0; slot < cache.axis_error_code.size(); ++slot) {
        if (cache.axis_error_code[slot] == 0) {
            continue;
        }

        const char* master_name = slot < 7 ? "master" : "master1";
        const unsigned int axis_index = slot < 7 ? static_cast<unsigned int>(slot)
                                                 : static_cast<unsigned int>(slot - 7);
        printf(
            " slot%zu{%s axis:%u err:0x%04x}",
            slot,
            master_name,
            axis_index,
            cache.axis_error_code[slot]);
        found_error = true;
    }

    if (!found_error) {
        printf(" none");
    }

    printf("\n");
}

bool SlotHasConfiguredDrive(const MasterContext& master0, const MasterContext& master1_ctx, uint8_t slot)
{
    if (slot < 7) {
        return IsValidAxisIndex(slot) && master0.axis_drive_kinds[slot] != DriveKind::Unknown;
    }

    const uint8_t axis_index = static_cast<uint8_t>(slot - 7);
    return IsValidAxisIndex(axis_index) && master1_ctx.axis_drive_kinds[axis_index] != DriveKind::Unknown;
}

void ResetEnableSequence()
{
    enable_sequence_allowed_slots.fill(false);
    enable_sequence_cursor = 0;
    enable_sequence_active = false;
}

bool HasAnyFaultOrError(const CycleCache& cache)
{
    return CheckAnyAxisFault(cache) || HasAnyAxisErrorCode(cache);
}

void AdvanceEnableSequenceIfNeeded(
    const MasterContext& master0,
    const MasterContext& master1_ctx,
    const CycleCache& cache)
{
    if (ec_shm_desire_axis_data.ec_poweron != 1) {
        ResetEnableSequence();
        fault_inhibit_active = false;
        return;
    }

    if (HasAnyFaultOrError(cache)) {
        if (!fault_inhibit_active) {
            printf("fault inhibit active: stop enabling all axes until faults are cleared\n");
            PrintAxisErrorCodeLog(cache);
        }
        fault_inhibit_active = true;
        ResetEnableSequence();
        return;
    }

    fault_inhibit_active = false;

    if (!enable_sequence_active) {
        enable_sequence_active = true;
        enable_sequence_allowed_slots.fill(false);
        enable_sequence_cursor = 0;
    }

    for (uint8_t slot = 0; slot < 14; ++slot) {
        if (!SlotHasConfiguredDrive(master0, master1_ctx, slot)) {
            continue;
        }
        if (cache.state[slot] == STATE_OPERATION_ENABLED) {
            enable_sequence_allowed_slots[slot] = true;
        }
    }

    while (enable_sequence_cursor < 14 &&
           !SlotHasConfiguredDrive(master0, master1_ctx, enable_sequence_cursor)) {
        ++enable_sequence_cursor;
    }

    if (enable_sequence_cursor < 14) {
        enable_sequence_allowed_slots[enable_sequence_cursor] = true;
        if (cache.state[enable_sequence_cursor] == STATE_OPERATION_ENABLED) {
            ++enable_sequence_cursor;
            while (enable_sequence_cursor < 14 &&
                   !SlotHasConfiguredDrive(master0, master1_ctx, enable_sequence_cursor)) {
                ++enable_sequence_cursor;
            }
            if (enable_sequence_cursor < 14) {
                enable_sequence_allowed_slots[enable_sequence_cursor] = true;
            }
        }
    }
}

bool IsEnableAllowedForSlot(uint8_t slot)
{
    return slot < enable_sequence_allowed_slots.size() && enable_sequence_allowed_slots[slot];
}

double PulseToDegree(int32_t pulse)
{
    return static_cast<double>(pulse) * 360.0 / static_cast<double>(ENCODER_RES);
}

void PrintRuntimeSnapshotForMaster(
    const MasterContext& ctx,
    const AxisPdoOffsetTable& offsets,
    uint64_t snapshot_index)
{
    if (ctx.process_data == nullptr) {
        return;
    }

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    printf("%s runtime snapshot #%" PRIu64 "\n", GetMasterName(ctx), snapshot_index);
    for (uint16_t slave_pos = 0; slave_pos < count; ++slave_pos) {
        const uint8_t axis_index = ctx.drive_axis_map[slave_pos];
        if (!IsValidAxisIndex(axis_index)) {
            continue;
        }
        const uint8_t shared_slot = GetSharedAxisSlot(ctx, axis_index);

        const DriveKind drive_kind = ctx.slave_drive_kinds[slave_pos];
        if (drive_kind == DriveKind::Unknown) {
            continue;
        }

        const int32_t actual_position =
            EC_READ_S32(ctx.process_data + offsets.actual_position[axis_index]);
        const int32_t actual_velocity =
            EC_READ_S32(ctx.process_data + offsets.actual_velocity[axis_index]);
        const int16_t actual_torque =
            EC_READ_S16(ctx.process_data + offsets.actual_torque[axis_index]);
        const uint8_t desired_mode = ec_shm_desire_axis_data.axis_ctr[shared_slot].ec_mode;
        const uint16_t desired_ctrword = ec_shm_desire_axis_data.axis_ctr[shared_slot].ec_ctrword;
        const int32_t desired_position = ec_shm_desire_axis_data.axis_ctr[shared_slot].axis_position;
        const int32_t desired_velocity = ec_shm_desire_axis_data.axis_ctr[shared_slot].axis_velocity;
        const int32_t desired_effort = ec_shm_desire_axis_data.axis_ctr[shared_slot].axis_effort;
        const uint8_t command_mode = ec_shm_to_axis_data.axis_ctr[shared_slot].ec_mode;
        const uint16_t command_ctrword = ec_shm_to_axis_data.axis_ctr[shared_slot].ec_ctrword;
        const int32_t command_position = ec_shm_to_axis_data.axis_ctr[shared_slot].axis_position;
        const int32_t command_velocity = ec_shm_to_axis_data.axis_ctr[shared_slot].axis_velocity;
        const int32_t command_effort = ec_shm_to_axis_data.axis_ctr[shared_slot].axis_effort;
        const uint8_t mode_display =
            EC_READ_U8(ctx.process_data + offsets.actual_modestate[axis_index]);
        const uint16_t statusword =
            EC_READ_U16(ctx.process_data + offsets.statusword[axis_index]);
        const uint16_t axis_error_code = IsOptionalOffsetRegistered(offsets.axis_error_code[axis_index])
            ? EC_READ_U16(ctx.process_data + offsets.axis_error_code[axis_index])
            : 0;
        const int32_t encoder_0 = IsOptionalOffsetRegistered(offsets.actual_encoder_0[axis_index])
            ? EC_READ_S32(ctx.process_data + offsets.actual_encoder_0[axis_index])
            : 0;
        const int32_t encoder_1 = IsOptionalOffsetRegistered(offsets.actual_encoder_1[axis_index])
            ? EC_READ_S32(ctx.process_data + offsets.actual_encoder_1[axis_index])
            : 0;

        printf(
            "  slot:%u axis:%u slave:%u drive:%s shm{mode:0x%02x cw:0x%04x pos:%d vel:%d eff:%d} cmd{mode:0x%02x cw:0x%04x pos:%d vel:%d eff:%d} fb{mode:0x%02x status:0x%04x fault:%s err:0x%04x pos:%d pos_deg:%.3f vel:%d tq:%d enc0:%d enc0_deg:%.3f enc1:%d enc1_deg:%.3f}\n",
            shared_slot,
            axis_index,
            slave_pos,
            GetDriveKindName(drive_kind),
            desired_mode,
            desired_ctrword,
            desired_position,
            desired_velocity,
            desired_effort,
            command_mode,
            command_ctrword,
            command_position,
            command_velocity,
            command_effort,
            mode_display,
            statusword,
            (statusword & AXIS_STATUES_ERR) != 0 ? "yes" : "no",
            axis_error_code,
            actual_position,
            PulseToDegree(actual_position),
            actual_velocity,
            actual_torque,
            encoder_0,
            PulseToDegree(encoder_0),
            encoder_1,
            PulseToDegree(encoder_1));
    }
}

void PrintRuntimeSnapshot(
    const MasterContext& master0,
    const MasterContext& master1_ctx,
    const AxisPdoOffsetTable& offsets,
    uint64_t snapshot_index)
{
    PrintRuntimeSnapshotForMaster(master0, offsets, snapshot_index);
    PrintRuntimeSnapshotForMaster(master1_ctx, offsets, snapshot_index);
}

bool CreateAxisErrorCodeRequest(MasterContext& ctx, uint8_t axis_index, ec_slave_config_t* slave_config)
{
    ec_sdo_request_t* request =
        ecrt_slave_config_create_sdo_request(slave_config, 0x603F, 0x00, sizeof(uint16_t));
    if (request == nullptr) {
        printf("%s axis:%u failed to create 0x603F SDO request\n",
               GetMasterName(ctx),
               axis_index);
        return false;
    }

    if (ecrt_sdo_request_timeout(request, kAxisErrorRequestTimeoutMs)) {
        printf("%s axis:%u failed to set 0x603F SDO timeout\n",
               GetMasterName(ctx),
               axis_index);
        return false;
    }

    ctx.axis_error_code_requests[axis_index] = request;
    return true;
}

bool CreateZeroResetEncoderRequest(MasterContext& ctx, uint8_t axis_index, ec_slave_config_t* slave_config)
{
    ec_sdo_request_t* request =
        ecrt_slave_config_create_sdo_request(slave_config, 0x2242, 0x00, sizeof(uint16_t));
    if (request == nullptr) {
        printf("%s axis:%u failed to create 0x2242 SDO request\n",
               GetMasterName(ctx),
               axis_index);
        return false;
    }

    if (ecrt_sdo_request_timeout(request, 1000)) {
        printf("%s axis:%u failed to set 0x2242 SDO timeout\n",
               GetMasterName(ctx),
               axis_index);
        return false;
    }

    ctx.zero_reset_encoder_requests[axis_index] = request;
    return true;
}

void PublishAxisErrorCode(uint8_t axis_index, uint16_t axis_error_code)
{
    if (ec_shm_real_axis_data_ptr == nullptr || axis_index >= kAxisStateSlotCount) {
        return;
    }

    ec_shm_real_axis_data_ptr->axis_state[axis_index].axis_error_code = axis_error_code;
}

void PublishAxisErrorCode(const MasterContext& ctx, uint8_t axis_index, uint16_t axis_error_code)
{
    PublishAxisErrorCode(GetSharedAxisSlot(ctx, axis_index), axis_error_code);
}

void PollAxisErrorCodeRequests(MasterContext& ctx, CycleCache& cache)
{
    if (ctx.configured_drive_count == 0) {
        return;
    }

    ++ctx.axis_error_poll_divider;
    if (ctx.axis_error_poll_divider < kAxisErrorPollPeriodCycles) {
        return;
    }
    ctx.axis_error_poll_divider = 0;

    for (std::size_t attempt = 0; attempt < kMaxZeroAxisCount; ++attempt) {
        const uint8_t axis_index =
            static_cast<uint8_t>((ctx.axis_error_poll_cursor + attempt) % kMaxZeroAxisCount);
        ec_sdo_request_t* request = ctx.axis_error_code_requests[axis_index];
        if (request == nullptr) {
            continue;
        }

        const ec_request_state_t request_state = ecrt_sdo_request_state(request);
        if (request_state == EC_REQUEST_BUSY) {
            continue;
        }

        if (request_state == EC_REQUEST_SUCCESS &&
            ecrt_sdo_request_data_size(request) >= sizeof(uint16_t)) {
            const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);
            cache.axis_error_code[slot] = EC_READ_U16(ecrt_sdo_request_data(request));
            PublishAxisErrorCode(ctx, axis_index, cache.axis_error_code[slot]);
        }

        if (ecrt_sdo_request_read(request)) {
            printf("%s axis:%u failed to schedule 0x603F SDO read\n",
                   GetMasterName(ctx),
                   axis_index);
        }

        ctx.axis_error_poll_cursor = static_cast<uint8_t>((axis_index + 1) % kMaxZeroAxisCount);
        return;
    }
}

bool ProbeSingleMaster(MasterContext& ctx)
{
    ctx.handle = ecrt_request_master(ctx.master_index);
    if (ctx.handle == nullptr) {
        printf("Requesting %s failed\n", GetMasterName(ctx));
        return false;
    }

    ec_master_info_t master_info{};
    ecrt_master(ctx.handle, &master_info);
    ctx.slave_count = master_info.slave_count;
    printf("%s detected slave_count:%u\n", GetMasterName(ctx), ctx.slave_count);
    LoadSlaveInfos(ctx);
    return true;
}

bool InspectMasterOperationalState(MasterContext& ctx, bool& operational_ok)
{
    if (ctx.slave_count == 0) {
        return true;
    }

    ecrt_master_receive(ctx.handle);

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        if (ctx.slave_configs[i] == nullptr) {
            continue;
        }

        ecrt_slave_config_state(ctx.slave_configs[i], &ctx.slave_states[i]);
        if (ctx.slave_states[i].operational) {
            printf("%s slave:%d have operational_ok OP state\n", GetMasterName(ctx), i);
        } else {
            printf("%s slave:%d have operational_nook OP state\n", GetMasterName(ctx), i);
            operational_ok = false;
        }
    }

    return true;
}

} // namespace

DriveKind ResolveDriveKindForAxis(uint8_t axis_index)
{
    if (axis_index < kPhysicalDriveKinds.size()) {
        return kPhysicalDriveKinds[axis_index];
    }
    return DriveKind::Unknown;
}

const char* GetDriveKindName(DriveKind drive_kind)
{
    switch (drive_kind) {
    case DriveKind::ZeroLegacy:
        return "ZeroLegacy";
    case DriveKind::ZeroEyou:
        return "ZeroEyou";
    case DriveKind::EyouPhV145:
        return "EyouPhV145";
    case DriveKind::Unknown:
    default:
        return "Unknown";
    }
}

const ZeroCompatibleProfile* GetZeroCompatibleProfileForAxis(
    const MasterContext& ctx,
    uint8_t axis_index)
{
    return IsValidAxisIndex(axis_index) ? ctx.axis_zero_profiles[axis_index] : nullptr;
}

/* 只负责读取从站描述信息，不做任何配置。 */
void LoadSlaveInfos(MasterContext& ctx)
{
    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        ecrt_master_get_slave(ctx.handle, i, &ctx.slave_infos[i]);
    }
}

/* 统一申请两个 master，并在这里完成 slave 总数检查。 */
bool RequestAndProbeMasters(MasterContext& master0, MasterContext& master1_ctx, uint16_t& totalSlaveCount)
{
    if (!ProbeSingleMaster(master0)) {
        return false;
    }

    master = master0.handle;

    if (!ProbeSingleMaster(master1_ctx)) {
        ReleaseMasterIfNeeded(master);
        master0.handle = nullptr;
        return false;
    }

    master1 = master1_ctx.handle;
    totalSlaveCount = static_cast<uint16_t>(master0.slave_count + master1_ctx.slave_count);

    if (totalSlaveCount > kMaxZeroAxisCount) {
        printf("Fail master_info.slave_count: %d\n", totalSlaveCount);
        ReleaseMasterIfNeeded(master);
        ReleaseMasterIfNeeded(master1);
        master0.handle = nullptr;
        master1_ctx.handle = nullptr;
        return false;
    }

    printf("master_info.slave_count: %d\n", totalSlaveCount);
    return true;
}

/* 绑定 slave config，并建立 local slave 到轴号和驱动类型的映射关系。 */
bool InitializeMixedDrives(MasterContext& ctx)
{
    ctx.drive_axis_map.fill(kInvalidAxisIndex);
    ctx.slave_uses_alias_selection.fill(false);
    ctx.slave_drive_kinds.fill(DriveKind::Unknown);
    ctx.slave_zero_profiles.fill(nullptr);
    ctx.axis_drive_kinds.fill(DriveKind::Unknown);
    ctx.axis_zero_profiles.fill(nullptr);
    ctx.drive_configs.fill(nullptr);
    ctx.axis_error_code_requests.fill(nullptr);
    ctx.zero_reset_encoder_requests.fill(nullptr);
    ctx.slave_configs.fill(nullptr);
    ctx.reference_drive = nullptr;
    ctx.configured_drive_count = 0;
    ctx.axis_error_poll_cursor = 0;
    ctx.axis_error_poll_divider = 0;

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        const ec_slave_info_t& slave_info = ctx.slave_infos[i];

        uint8_t axis_index = kInvalidAxisIndex;
        bool uses_alias_selection = false;
        if (!ResolveAxisIndexFromAliasOrPosition(ctx, i, slave_info, axis_index, uses_alias_selection)) {
            printf(
                "%s slaveid:%d alias:%u cannot resolve axis from alias or slave position\n",
                GetMasterName(ctx),
                i,
                slave_info.alias);
            continue;
        }

        if (!uses_alias_selection) {
            printf(
                "%s slaveid:%d alias:%u fallback to slave-position mapping axis:%u\n",
                GetMasterName(ctx),
                i,
                slave_info.alias,
                axis_index);
        }

        if (!IsAxisInActiveRange(axis_index)) {
            printf("%s slaveid:%d axis:%u out of active mixed-drive range, skip\n",
                   GetMasterName(ctx),
                   i,
                   axis_index);
            continue;
        }

        const DriveKind expected_drive_kind = ResolveDriveKindForAxis(axis_index);
        const ZeroCompatibleProfile* zero_profile = nullptr;
        DriveKind drive_kind = expected_drive_kind;
        const bool vendor_match =
            (expected_drive_kind == DriveKind::EyouPhV145 &&
             slave_info.vendor_id == kEyouPhVendorId &&
             slave_info.product_code == kEyouPhProductCode) ||
            (IsZeroCompatibleDriveKind(expected_drive_kind) &&
             ((zero_profile = MatchZeroCompatibleProfile(slave_info)) != nullptr) &&
             (drive_kind = zero_profile->drive_kind, true));
        if (!vendor_match) {
            printf("%s slaveid:%d axis:%u expected:%s but got vendor:0x%08x product:0x%08x\n",
                   GetMasterName(ctx),
                   i,
                   axis_index,
                   GetDriveKindName(expected_drive_kind),
                   slave_info.vendor_id,
                   slave_info.product_code);
            continue;
        }

        ec_slave_config_t* slave_config = nullptr;
        const uint16_t config_alias = uses_alias_selection ? slave_info.alias : 0;
        const uint16_t config_position = uses_alias_selection ? 0 : i;
        if (drive_kind == DriveKind::EyouPhV145) {
            slave_config = ecrt_master_slave_config(
                ctx.handle,
                config_alias,
                config_position,
                kEyouPhVendorId,
                kEyouPhProductCode);
        } else if (IsZeroCompatibleDriveKind(drive_kind)) {
            slave_config = ecrt_master_slave_config(
                ctx.handle,
                config_alias,
                config_position,
                slave_info.vendor_id,
                slave_info.product_code);
        }

        if (slave_config == nullptr) {
            printf("%s failed to get %s configuration for axis:%u vendor:0x%08x product:0x%08x\n",
                   GetMasterName(ctx),
                   GetDriveKindName(drive_kind),
                   axis_index,
                   slave_info.vendor_id,
                   slave_info.product_code);
            return false;
        }

        if (drive_kind == DriveKind::EyouPhV145) {
            init_chage_Drive(ctx.handle, i, CONTROL_WORD_CSP);
        } else if (IsZeroCompatibleDriveKind(drive_kind)) {
            if (!initDrive_zero(
                    ctx.handle,
                    i,
                    CONTROL_WORD_CSP,
                    zero_profile != nullptr ? zero_profile->name : GetDriveKindName(drive_kind))) {
                printf("%s axis:%u zero-compatible init failed\n",
                       GetMasterName(ctx),
                       axis_index);
            }
        }

        ctx.slave_configs[i] = slave_config;
        ctx.slave_uses_alias_selection[i] = uses_alias_selection;
        ctx.slave_drive_kinds[i] = drive_kind;
        ctx.slave_zero_profiles[i] = zero_profile;
        ctx.axis_drive_kinds[axis_index] = drive_kind;
        ctx.axis_zero_profiles[axis_index] = zero_profile;
        ctx.drive_configs[axis_index] = slave_config;
        ctx.drive_axis_map[i] = axis_index;

        if (IsZeroCompatibleDriveKind(drive_kind) &&
            !CreateAxisErrorCodeRequest(ctx, axis_index, slave_config)) {
            return false;
        }
        if (zero_profile != nullptr &&
            zero_profile->supports_zero_reset &&
            !CreateZeroResetEncoderRequest(ctx, axis_index, slave_config)) {
            return false;
        }

        if (ctx.reference_drive == nullptr) {
            ctx.reference_drive = slave_config;
        }

        ++ctx.configured_drive_count;
        printf(
               "%s slave local:%d axis:%d drive:%s vendor:0x%08x product:0x%08x encoders:[0x%04x,0x%04x] map:%s success to get mixed configuration\n",
               GetMasterName(ctx),
               i,
               axis_index,
               GetDriveKindName(drive_kind),
               slave_info.vendor_id,
               slave_info.product_code,
               zero_profile != nullptr ? zero_profile->encoder_0_index : 0,
               zero_profile != nullptr ? zero_profile->encoder_1_index : 0,
               uses_alias_selection ? "alias" : "slave_position");
    }

    PrintAxisBindingSummary(ctx);

    return true;
}

/* PDO 配置阶段独立出来，后续更换映射时不影响初始化逻辑。 */
bool ConfigureMixedPdos(MasterContext& ctx)
{
#ifdef CONFIG_PDOS
    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        if (ctx.slave_configs[i] == nullptr) {
            continue;
        }

        const DriveKind drive_kind = ctx.slave_drive_kinds[i];
        const ec_sync_info_t* drive_syncs = GetDriveSyncs(ctx, i);
        if (drive_syncs == nullptr) {
            continue;
        }

        if (ecrt_slave_config_pdos(
                ctx.slave_configs[i],
                EC_END,
                const_cast<ec_sync_info_t*>(drive_syncs))) {
            printf("Failed to configure %s PDO mappings on %s slave:%d\n",
                   GetDriveKindName(drive_kind),
                   GetMasterName(ctx),
                   i);
            return false;
        }

        printf("success to configure %s PDO mappings on %s slave:%d\n",
               GetDriveKindName(drive_kind),
               GetMasterName(ctx),
               i);
    }
#endif

    return true;
}

/* 为混用轴生成 PDO offset 注册项。 */
std::vector<ec_pdo_entry_reg_t> BuildMixedDomainRegs(const MasterContext& ctx, AxisPdoOffsetTable& offsets)
{
    std::vector<ec_pdo_entry_reg_t> regs;
    offsets.operation_mode.fill(kInvalidPdoOffset);
    offsets.controlword.fill(kInvalidPdoOffset);
    offsets.statusword.fill(kInvalidPdoOffset);
    offsets.target_position.fill(kInvalidPdoOffset);
    offsets.actual_position.fill(kInvalidPdoOffset);
    offsets.digital_output.fill(kInvalidPdoOffset);
    offsets.target_velocity.fill(kInvalidPdoOffset);
    offsets.target_torque.fill(kInvalidPdoOffset);
    offsets.actual_velocity.fill(kInvalidPdoOffset);
    offsets.velocity_offset.fill(kInvalidPdoOffset);
    offsets.torque_offset.fill(kInvalidPdoOffset);
    offsets.actual_torque.fill(kInvalidPdoOffset);
    offsets.actual_encoder_0.fill(kInvalidPdoOffset);
    offsets.actual_encoder_1.fill(kInvalidPdoOffset);
    offsets.actual_modestate.fill(kInvalidPdoOffset);
    offsets.axis_error_code.fill(kInvalidPdoOffset);
    regs.reserve(static_cast<std::size_t>(ctx.configured_drive_count) * 16U + 1U);

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        const uint8_t axis_index = ctx.drive_axis_map[i];
        if (!IsValidAxisIndex(axis_index)) {
            continue;
        }

        const DriveKind drive_kind = ctx.slave_drive_kinds[i];
        const ZeroCompatibleProfile* zero_profile = ctx.slave_zero_profiles[i];
        const uint32_t vendor_id = ctx.slave_infos[i].vendor_id;
        const uint32_t product_code = ctx.slave_infos[i].product_code;
        const uint16_t reg_alias = ctx.slave_uses_alias_selection[i] ? ctx.slave_infos[i].alias : 0;
        const uint16_t reg_position = ctx.slave_uses_alias_selection[i] ? 0 : i;

        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6040, 0x00,
            &offsets.controlword[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x607A, 0x00,
            &offsets.target_position[axis_index]});
        if (drive_kind == DriveKind::EyouPhV145 || drive_kind == DriveKind::ZeroLegacy) {
            regs.push_back(ec_pdo_entry_reg_t{
                reg_alias, reg_position, vendor_id, product_code, 0x60FF, 0x00,
                &offsets.target_velocity[axis_index]});
        }
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6071, 0x00,
            &offsets.target_torque[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6060, 0x00,
            &offsets.operation_mode[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6041, 0x00,
            &offsets.statusword[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6064, 0x00,
            &offsets.actual_position[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x606C, 0x00,
            &offsets.actual_velocity[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6077, 0x00,
            &offsets.actual_torque[axis_index]});
        regs.push_back(ec_pdo_entry_reg_t{
            reg_alias, reg_position, vendor_id, product_code, 0x6061, 0x00,
            &offsets.actual_modestate[axis_index]});

        if (drive_kind == DriveKind::EyouPhV145) {
            regs.push_back(ec_pdo_entry_reg_t{
                reg_alias, reg_position, vendor_id, product_code, 0x603F, 0x00,
                &offsets.axis_error_code[axis_index]});
        } else if (IsZeroCompatibleDriveKind(drive_kind)) {
            if (drive_kind == DriveKind::ZeroEyou) {
                regs.push_back(ec_pdo_entry_reg_t{
                    reg_alias, reg_position, vendor_id, product_code, 0x60FE, 0x00,
                    &offsets.digital_output[axis_index]});
            }
            if (zero_profile != nullptr && zero_profile->encoder_0_index != 0) {
                regs.push_back(ec_pdo_entry_reg_t{
                    reg_alias, reg_position, vendor_id, product_code, zero_profile->encoder_0_index, 0x00,
                    &offsets.actual_encoder_0[axis_index]});
            }
            if (zero_profile != nullptr && zero_profile->encoder_1_index != 0) {
                regs.push_back(ec_pdo_entry_reg_t{
                    reg_alias, reg_position, vendor_id, product_code, zero_profile->encoder_1_index, 0x00,
                    &offsets.actual_encoder_1[axis_index]});
            }
        }
    }

    regs.push_back(ec_pdo_entry_reg_t{});
    return regs;
}

bool CreateAndRegisterDomain(MasterContext& ctx, const std::vector<ec_pdo_entry_reg_t>& regs)
{
    ctx.domain = ecrt_master_create_domain(ctx.handle);
    if (ctx.domain == nullptr) {
        printf("Failed to create domain for %s\n", GetMasterName(ctx));
        return false;
    }

    if (ecrt_domain_reg_pdo_entry_list(ctx.domain, regs.data())) {
        printf("%s PDO entry registration failed\n", GetMasterName(ctx));
        return false;
    }

    return true;
}

/* DC 配置单独收口，主流程就能保持阶段清晰。 */
void ConfigureDistributedClocksIfEnabled(MasterContext& ctx)
{
#ifdef CONFIG_DC
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    ecrt_master_application_time(ctx.handle, EC_NEWTIMEVAL2NANO(now));

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        if (ctx.slave_configs[i] == nullptr) {
            continue;
        }

        const DriveKind drive_kind = ctx.slave_drive_kinds[i];
        const uint16_t assign_activate =
            drive_kind == DriveKind::EyouPhV145 ? kEyouPhDcAssignActivate : 0x0300;
        ecrt_slave_config_dc(ctx.slave_configs[i], assign_activate, PERIOD_NS, 0, 0, 0);
    }
#endif

#ifdef SYNC_REF_TO_MASTER
    struct timespec master_init_time;
    clock_gettime(CLOCK_MONOTONIC, &master_init_time);
    ecrt_master_application_time(ctx.handle, TIMESPEC2NS(master_init_time));
#endif

#ifdef SYNC_MASTER_TO_REF
    if (ctx.reference_drive != nullptr) {
        ctx.dc_sync.dc_start_time_ns = system_time_ns(ctx.dc_sync);
        ctx.dc_sync.dc_time_ns = ctx.dc_sync.dc_start_time_ns;
        ecrt_master_application_time(ctx.handle, ctx.dc_sync.dc_start_time_ns);

        if (ecrt_master_select_reference_clock(ctx.handle, ctx.reference_drive)) {
            printf("Selecting slave 0 as reference clock failed on %s!\n", GetMasterName(ctx));
        }
    }
#endif
}

bool ActivateMasterAndFetchDomainData(MasterContext& ctx)
{
    if (ctx.slave_count == 0) {
        return true;
    }

    if (ecrt_master_activate(ctx.handle)) {
        printf("Activating %s failed\n", GetMasterName(ctx));
        return false;
    }

    ctx.process_data = ecrt_domain_data(ctx.domain);
    if (ctx.process_data == nullptr) {
        printf("Fetching %s domain data failed\n", GetMasterName(ctx));
        return false;
    }

    return true;
}

/* 收包和 domain_process 总是成对出现，单独封装让循环更干净。 */
void ReceiveAndProcessDomains(MasterContext& ctx, CycleCache& cache)
{
    if (ctx.slave_count == 0) {
        return;
    }

    ecrt_master_receive(ctx.handle);

    if (ctx.domain != nullptr) {
        ecrt_domain_process(ctx.domain);
    }

#ifdef MEASURE_PERF
    ecrt_master_reference_clock_time(ctx.handle, &cache.t_cur);
#endif
}

/* 反馈统一回写到共享内存，APP 只读取整理后的状态。 */
void ReadAxisFeedbackFromMaster(const MasterContext& ctx, const AxisPdoOffsetTable& offsets, CycleCache& cache)
{
    if (ctx.process_data == nullptr || ec_shm_real_axis_data_ptr == nullptr) {
        return;
    }

    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        const uint8_t axis_index = ctx.drive_axis_map[i];
        if (!IsValidAxisIndex(axis_index)) {
            continue;
        }
        const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);

        const DriveKind drive_kind = ctx.slave_drive_kinds[i];
        if (drive_kind == DriveKind::Unknown) {
            continue;
        }

        cache.act_pos[slot] =
            EC_READ_S32(ctx.process_data + offsets.actual_position[axis_index]);
        cache.act_vel[slot] =
            EC_READ_S32(ctx.process_data + offsets.actual_velocity[axis_index]);
        if (IsOptionalOffsetRegistered(offsets.actual_encoder_0[axis_index])) {
            cache.encoder_0[slot] =
                EC_READ_S32(ctx.process_data + offsets.actual_encoder_0[axis_index]);
        } else {
            cache.encoder_0[slot] = 0;
        }
        if (IsOptionalOffsetRegistered(offsets.actual_encoder_1[axis_index])) {
            cache.encoder_1[slot] =
                EC_READ_S32(ctx.process_data + offsets.actual_encoder_1[axis_index]);
        } else {
            cache.encoder_1[slot] = 0;
        }
        cache.mode_word[slot] =
            EC_READ_U8(ctx.process_data + offsets.actual_modestate[axis_index]);
        cache.status_word[slot] =
            EC_READ_U16(ctx.process_data + offsets.statusword[axis_index]);
        cache.state[slot] = getDriveState(cache.status_word[slot]);
        if (IsOptionalOffsetRegistered(offsets.axis_error_code[axis_index])) {
            cache.axis_error_code[slot] =
                EC_READ_U16(ctx.process_data + offsets.axis_error_code[axis_index]);
        }

        ec_shm_real_axis_data_ptr->axis_state[slot].axis_position = cache.act_pos[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].axis_velocity = cache.act_vel[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].axis_effort =
            EC_READ_S16(ctx.process_data + offsets.actual_torque[axis_index]);
        ec_shm_real_axis_data_ptr->axis_state[slot].axis_encoder_0 = cache.encoder_0[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].axis_encoder_1 = cache.encoder_1[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].axis_error_code =
            cache.axis_error_code[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].ec_ctrstate = cache.state[slot];
        ec_shm_real_axis_data_ptr->axis_state[slot].ec_modestate = cache.mode_word[slot];
    }
}

bool CheckAnyAxisFault(const CycleCache& cache)
{
    for (std::size_t i = 0; i < cache.status_word.size(); ++i) {
        if (cache.status_word[i] & AXIS_STATUES_ERR) {
            return true;
        }
    }

    if (ec_shm_real_axis_data_ptr != nullptr) {
        for (std::size_t i = 0; i < kAxisStateSlotCount; ++i) {
            if (ec_shm_real_axis_data_ptr->axis_state[i].ec_ctrstate & AXIS_STATUES_ERR) {
                return true;
            }
        }
    }

    return false;
}

/* 从共享内存拉取 APP 最新命令。 */
void RefreshDesiredCommandsFromSharedMemory()
{
    if (ec_shm_desire_axis_data_ptr == nullptr) {
        return;
    }

    std::memcpy(&ec_shm_desire_axis_data, ec_shm_desire_axis_data_ptr, sizeof(ec_app_read_reg_t));
}

bool IsDrivePowerOnRequested()
{
    return ec_shm_desire_axis_data.ec_poweron == 1;
}

void ApplyAxisEnableGate(uint8_t command_slot, uint16_t drive_state)
{
    if (IsDrivePowerOnRequested() && IsEnableAllowedForSlot(command_slot)) {
        axis_ctrword_state_chage(drive_state, command_slot);
    } else {
        ec_shm_to_axis_data.axis_ctr[command_slot].ec_ctrword = CONTROL_WORD_SHUTDOWN;
    }
}

void ApplyZeroEnableGate(uint8_t command_slot, uint16_t drive_state)
{
    /* 兼容旧 zero 逻辑：zero 上使能前必须先具备 0x0F 使能请求。 */
    ec_shm_desire_axis_data.axis_ctr[command_slot].ec_ctrword = CONTROL_WORD_ENABLE_OPERATION;

    if (IsDrivePowerOnRequested() &&
        IsEnableAllowedForSlot(command_slot) &&
        ec_shm_desire_axis_data.axis_ctr[command_slot].ec_ctrword == CONTROL_WORD_ENABLE_OPERATION) {
        axis_ctrword_state_chage(drive_state, command_slot);
    } else {
        ec_shm_to_axis_data.axis_ctr[command_slot].ec_ctrword = CONTROL_WORD_SHUTDOWN;
    }
}

uint8_t NormalizeZeroCompatibleMode(uint8_t requested_mode)
{
    return requested_mode == AXIS_MODE_CST ? AXIS_MODE_CST : AXIS_MODE_CSP;
}

void PrepareZeroCompatibleAxisCommand(const MasterContext& ctx, uint8_t axis_index, const CycleCache& cache)
{
    const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);
    const uint8_t requested_mode =
        NormalizeZeroCompatibleMode(ec_shm_desire_axis_data.axis_ctr[slot].ec_mode);
    const bool power_on_requested = IsDrivePowerOnRequested();

    ec_shm_to_axis_data.axis_ctr[slot].ec_mode = requested_mode;
    ec_shm_to_axis_data.axis_ctr[slot].axis_velocity = 0;

    if (!power_on_requested) {
        hold_position_initialized[slot] = false;
        ResetZeroCspReentryHold(slot);
    }

    if (requested_mode == AXIS_MODE_CST) {
        if (zero_previous_mode[slot] != AXIS_MODE_CST || !hold_position_initialized[slot]) {
            hold_positions[slot] = cache.act_pos[slot];
            hold_position_initialized[slot] = true;
        }
        ResetZeroCspReentryHold(slot);
    } else if (requested_mode == AXIS_MODE_CSP) {
        if (zero_previous_mode[slot] == AXIS_MODE_CST) {
            hold_positions[slot] = cache.act_pos[slot];
            hold_position_initialized[slot] = true;
            zero_csp_reentry_hold_active[slot] = true;
            zero_csp_reentry_ready_cycles[slot] = 0;
            zero_csp_reentry_takeover_cycles[slot] = 0;
        }
        UpdateZeroCspReentryHoldState(slot, cache);
    } else {
        ResetZeroCspReentryHold(slot);
    }

    if (requested_mode == AXIS_MODE_CST) {
        ec_shm_to_axis_data.axis_ctr[slot].axis_position =
            hold_position_initialized[slot] ? hold_positions[slot] : cache.act_pos[slot];
        ec_shm_to_axis_data.axis_ctr[slot].axis_effort =
            ec_shm_desire_axis_data.axis_ctr[slot].axis_effort;
    } else {
        ec_shm_to_axis_data.axis_ctr[slot].axis_position =
            zero_csp_reentry_hold_active[slot] && hold_position_initialized[slot]
                ? hold_positions[slot]
                : ec_shm_desire_axis_data.axis_ctr[slot].axis_position;
        ec_shm_to_axis_data.axis_ctr[slot].axis_effort = 0;
    }

    axis_mode_state_chage(
        cache.mode_word[slot],
        requested_mode,
        slot,
        cache.state[slot],
        cache.act_pos[slot],
        ec_shm_to_axis_data.axis_ctr[slot].axis_position,
        cache.act_vel[slot],
        0);

    ApplyZeroEnableGate(slot, cache.state[slot]);
    zero_previous_mode[slot] = requested_mode;
}

void ApplyModeSwitchGroupOutputs(const CycleCache& cache)
{
    for (const uint8_t axis_index : kModeSwitchAxes) {
        ec_shm_to_axis_data.axis_ctr[axis_index].ec_mode = mode_switch_test_ctx.requested_mode;
        ec_shm_to_axis_data.axis_ctr[axis_index].axis_position = hold_positions[axis_index];
        ec_shm_to_axis_data.axis_ctr[axis_index].axis_velocity = 0;
        ec_shm_to_axis_data.axis_ctr[axis_index].axis_effort = 0;

        axis_mode_state_chage(
            cache.mode_word[axis_index],
            mode_switch_test_ctx.requested_mode,
            axis_index,
            cache.state[axis_index],
            cache.act_pos[axis_index],
            hold_positions[axis_index],
            cache.act_vel[axis_index],
            0);

        axis_ctrword_state_chage(cache.state[axis_index], axis_index);
    }
}

void PrepareArmGroupAxisCommand(const MasterContext& ctx, const CycleCache& cache)
{
    const uint8_t ctx_index = GetMasterContextIndex(ctx);
    const uint8_t base_slot = GetMasterSlotBase(ctx);
    const uint8_t requested_mode = NormalizeArmGroupMode(ec_shm_desire_axis_data.axis_ctr[base_slot].ec_mode);
    arm_group_requested_mode[ctx_index] = requested_mode;
    const bool power_on_requested = IsDrivePowerOnRequested();

    if (requested_mode != arm_group_previous_mode[ctx_index]) {
        printf(
            "arm_group_mode_switch: %s -> %s axis0_cmd:0x%02x actual_modes[a0,a7,a13]=[0x%02x,0x%02x,0x%02x]\n",
            GetAxisModeName(arm_group_previous_mode[ctx_index]),
            GetAxisModeName(requested_mode),
            ec_shm_desire_axis_data.axis_ctr[base_slot].ec_mode,
            cache.mode_word[GetSharedAxisSlot(ctx, kModeSwitchLogAxisFirst)],
            cache.mode_word[GetSharedAxisSlot(ctx, kModeSwitchLogAxisMiddle)],
            cache.mode_word[GetSharedAxisSlot(ctx, kModeSwitchLogAxisLast)]);
    }

    if (!power_on_requested) {
        ClearArmGroupHoldContext(ctx);
        ResetArmGroupCspReentryHold(ctx_index);
    }

    if (requested_mode == AXIS_MODE_CST) {
        if (arm_group_previous_mode[ctx_index] != AXIS_MODE_CST || !arm_group_hold_active[ctx_index]) {
            SnapshotModeSwitchAxisPositions(ctx, cache);
            arm_group_hold_active[ctx_index] = true;
        }
        ResetArmGroupCspReentryHold(ctx_index);
    } else {
        if (arm_group_previous_mode[ctx_index] == AXIS_MODE_CST && requested_mode == AXIS_MODE_CSP) {
            SnapshotModeSwitchAxisPositions(ctx, cache);
            arm_group_hold_active[ctx_index] = false;
            arm_group_csp_reentry_hold_active[ctx_index] = true;
            arm_group_csp_reentry_ready_cycles[ctx_index] = 0;
            arm_group_csp_reentry_takeover_cycles[ctx_index] = 0;
            printf("%s arm_group_mode_switch: enter CSP reentry hold using current feedback snapshot\n",
                   GetMasterName(ctx));
        } else if (requested_mode != AXIS_MODE_CSP) {
            ResetArmGroupCspReentryHold(ctx_index);
        }

        if (requested_mode == AXIS_MODE_CSP) {
            UpdateArmGroupCspReentryHoldState(ctx, cache);
        }
    }

    for (const uint8_t axis_index : kModeSwitchAxes) {
        if (!IsEyouPhDrive(ctx, axis_index)) {
            continue;
        }
        const uint8_t slot = GetSharedAxisSlot(ctx, axis_index);

        ec_shm_to_axis_data.axis_ctr[slot].ec_mode = requested_mode;

        if (requested_mode == AXIS_MODE_CST) {
            const int32_t hold_position =
                hold_position_initialized[slot] ? hold_positions[slot] : cache.act_pos[slot];

            ec_shm_to_axis_data.axis_ctr[slot].axis_position = hold_position;
            ec_shm_to_axis_data.axis_ctr[slot].axis_velocity = 0;
            ec_shm_to_axis_data.axis_ctr[slot].axis_effort =
                ec_shm_desire_axis_data.axis_ctr[slot].axis_effort;

            axis_mode_state_chage(
                cache.mode_word[slot],
                AXIS_MODE_CST,
                slot,
                cache.state[slot],
                cache.act_pos[slot],
                hold_position,
                cache.act_vel[slot],
                0);
        } else {
            const bool use_hold_position =
                requested_mode == AXIS_MODE_CSP && arm_group_csp_reentry_hold_active[ctx_index];
            const int32_t command_position =
                use_hold_position && hold_position_initialized[slot]
                    ? hold_positions[slot]
                    : ec_shm_desire_axis_data.axis_ctr[slot].axis_position;
            const int32_t command_velocity =
                use_hold_position ? 0 : ec_shm_desire_axis_data.axis_ctr[slot].axis_velocity;

            ec_shm_to_axis_data.axis_ctr[slot].axis_position = command_position;
            ec_shm_to_axis_data.axis_ctr[slot].axis_velocity = command_velocity;
            ec_shm_to_axis_data.axis_ctr[slot].axis_effort = 0;

            axis_mode_state_chage(
                cache.mode_word[slot],
                requested_mode,
                slot,
                cache.state[slot],
                cache.act_pos[slot],
                command_position,
                cache.act_vel[slot],
                command_velocity);
        }

        ApplyAxisEnableGate(slot, cache.state[slot]);
    }

    arm_group_previous_mode[ctx_index] = requested_mode;
    mode_switch_test_ctx.requested_mode = requested_mode;
}

/* 前14轴由 axis0.ec_mode 外部触发整组 CSP/CST 切换。 */
void UpdateAxisCommandState(const MasterContext& ctx, uint8_t axis_index, const CycleCache& cache, bool state_is_clean)
{
    (void)state_is_clean;

    if (axis_index >= axis_mode_states.size()) {
        return;
    }

    if (IsEyouPhDrive(ctx, axis_index) && IsModeSwitchAxis(axis_index)) {
        const uint8_t ctx_index = GetMasterContextIndex(ctx);
        if (!arm_group_prepared_this_cycle[ctx_index]) {
            PrepareArmGroupAxisCommand(ctx, cache);
            arm_group_prepared_this_cycle[ctx_index] = true;
        }
    } else if (IsZeroDrive(ctx, axis_index)) {
        PrepareZeroCompatibleAxisCommand(ctx, axis_index, cache);
    }
}

void WriteAxisCommandToDomain(
    uint8_t* process_data,
    const AxisPdoOffsetTable& offsets,
    DriveKind drive_kind,
    uint8_t axis_index,
    uint8_t command_slot)
{
    if (process_data == nullptr || !IsValidAxisIndex(axis_index)) {
        return;
    }

    /* 6060/6040 始终通过 PDO 下发，命令源由上层共享内存和当前轴模式决定。 */
    EC_WRITE_U8(
        process_data + offsets.operation_mode[axis_index],
        ec_shm_to_axis_data.axis_ctr[command_slot].ec_mode);
    EC_WRITE_U16(
        process_data + offsets.controlword[axis_index],
        ec_shm_to_axis_data.axis_ctr[command_slot].ec_ctrword);
    EC_WRITE_S16(
        process_data + offsets.target_torque[axis_index],
        static_cast<int16_t>(ec_shm_to_axis_data.axis_ctr[command_slot].axis_effort));
    if (drive_kind == DriveKind::ZeroEyou) {
        if (IsOptionalOffsetRegistered(offsets.digital_output[axis_index])) {
            EC_WRITE_U32(process_data + offsets.digital_output[axis_index], 0);
        }
    }

    if (drive_kind == DriveKind::ZeroEyou) {
        EC_WRITE_U32(
            process_data + offsets.target_position[axis_index],
            ec_shm_to_axis_data.axis_ctr[command_slot].axis_position);
        return;
    }

    if (axis_mode_states[command_slot] == AXIS_MODE_SUCCESS) {
        if (ec_shm_to_axis_data.axis_ctr[command_slot].ec_mode == AXIS_MODE_CSV) {
            EC_WRITE_S32(
                process_data + offsets.target_velocity[axis_index],
                ec_shm_to_axis_data.axis_ctr[command_slot].axis_velocity);
            EC_WRITE_U32(
                process_data + offsets.target_position[axis_index],
                ec_shm_to_axis_data.axis_ctr[command_slot].axis_position);
        } else if (ec_shm_to_axis_data.axis_ctr[command_slot].ec_mode == AXIS_MODE_CST) {
            EC_WRITE_S32(process_data + offsets.target_velocity[axis_index], 0);
            EC_WRITE_U32(
                process_data + offsets.target_position[axis_index],
                ec_shm_to_axis_data.axis_ctr[command_slot].axis_position);
        } else {
            EC_WRITE_S32(process_data + offsets.target_velocity[axis_index], 0);
            EC_WRITE_U32(
                process_data + offsets.target_position[axis_index],
                ec_shm_to_axis_data.axis_ctr[command_slot].axis_position);
        }
    } else {
        /* 模式尚未就绪时，不发送激进的运动指令，先保持安全占位值。 */
        EC_WRITE_S32(process_data + offsets.target_velocity[axis_index], 0);
        EC_WRITE_U32(
            process_data + offsets.target_position[axis_index],
            ec_shm_to_axis_data.axis_ctr[command_slot].axis_position);
    }
}

/* 双 master 的 PDO 下发统一走这里。 */
void WriteMasterOutputs(const MasterContext& ctx, const AxisPdoOffsetTable& offsets, CycleCache& cache)
{
    if (ctx.process_data == nullptr) {
        return;
    }

    const bool state_is_clean = !cache.any_axis_fault;
    const uint16_t count =
        std::min<uint16_t>(ctx.slave_count, static_cast<uint16_t>(ctx.slave_infos.size()));

    for (uint16_t i = 0; i < count; ++i) {
        const uint8_t axis_index = ctx.drive_axis_map[i];
        if (!IsValidAxisIndex(axis_index)) {
            continue;
        }
        const uint8_t command_slot = GetSharedAxisSlot(ctx, axis_index);

        const DriveKind drive_kind = ctx.slave_drive_kinds[i];
        if (drive_kind == DriveKind::Unknown) {
            continue;
        }

        UpdateAxisCommandState(ctx, axis_index, cache, state_is_clean);
        WriteAxisCommandToDomain(ctx.process_data, offsets, drive_kind, axis_index, command_slot);
    }
}

/* 同步与发送共用一层封装，OP 等待和正式循环都能复用。 */
void SyncAndSendMaster(MasterContext& ctx)
{
    if (ctx.slave_count == 0) {
        return;
    }

    if (ctx.domain != nullptr) {
        ecrt_domain_queue(ctx.domain);
    }

#ifdef SYNC_REF_TO_MASTER
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    ecrt_master_application_time(ctx.handle, TIMESPEC2NS(now));
    ecrt_master_sync_reference_clock(ctx.handle);
    ecrt_master_sync_slave_clocks(ctx.handle);
#endif

#ifdef SYNC_MASTER_TO_REF
    sync_distributed_clocks(ctx);
#endif

    ecrt_master_send(ctx.handle);

#ifdef SYNC_MASTER_TO_REF
    update_master_clock(ctx);
#endif
}

bool WaitUntilAllSlavesOperational(MasterContext& master0, MasterContext& master1_ctx)
{
    struct timespec wakeupTime;
    struct timespec cycleTime = {0, PERIOD_NS};
    clock_gettime(CLOCK_MONOTONIC, &wakeupTime);

    while (1) {
        bool operational_ok = true;

        timespec_add(&wakeupTime, &wakeupTime, &cycleTime);
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &wakeupTime, nullptr);

        InspectMasterOperationalState(master0, operational_ok);
        InspectMasterOperationalState(master1_ctx, operational_ok);

        if (operational_ok) {
            if (ec_shm_real_axis_data_ptr != nullptr) {
                ec_shm_real_axis_data_ptr->ec_powerstate = 1;
            }
            printf("ALL slaves have reached OP state\n");
            return true;
        }

        SyncAndSendMaster(master0);
        SyncAndSendMaster(master1_ctx);
    }
}

/* 实时循环主流程：
 * 1. 定时唤醒
 * 2. 收包处理
 * 3. 刷新反馈
 * 4. 读取 APP 命令
 * 5. 运行状态机并写出 PDO
 * 6. 同步时钟并发包
 */
void RunCyclicLoop(MasterContext& master0, MasterContext& master1_ctx, const AxisPdoOffsetTable& offsets)
{
    CycleCache cache;
    uint32_t time_log_flag = 0;
    uint32_t axis_error_log_counter = 0;
    uint32_t runtime_snapshot_counter = 0;
    uint64_t runtime_snapshot_index = 0;

    struct timespec wakeupTime;
    struct timespec cycleTime = {0, PERIOD_NS};
    struct timespec sleepTime = cycleTime;
    clock_gettime(CLOCK_MONOTONIC, &wakeupTime);

#ifdef MEASURE_TIMING
    struct timespec currentLoopTime{};
    struct timespec previousLoopTime = wakeupTime;
    struct timespec intervalTime{};
#endif

    while (1) {
        timespec_add(&wakeupTime, &wakeupTime, &sleepTime);
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &wakeupTime, nullptr);

#ifdef MEASURE_TIMING
        clock_gettime(CLOCK_MONOTONIC, &currentLoopTime);
        timespec_sub(&intervalTime, &currentLoopTime, &previousLoopTime);
        if ((intervalTime.tv_nsec > 1100000) ||
            (intervalTime.tv_nsec < 900000) ||
            (time_log_flag == 1)) {
            printf("testtimesub.tv_nsec time: %lu ns\n", intervalTime.tv_nsec);
        }
        previousLoopTime = currentLoopTime;
#endif

        ReceiveAndProcessDomains(master0, cache);
        ReceiveAndProcessDomains(master1_ctx, cache);

        ReadAxisFeedbackFromMaster(master0, offsets, cache);
        ReadAxisFeedbackFromMaster(master1_ctx, offsets, cache);
        PollAxisErrorCodeRequests(master0, cache);
        PollAxisErrorCodeRequests(master1_ctx, cache);

        cache.any_axis_fault = CheckAnyAxisFault(cache);
        RefreshDesiredCommandsFromSharedMemory();
        arm_group_prepared_this_cycle[0] = false;
        arm_group_prepared_this_cycle[1] = false;
        AdvanceEnableSequenceIfNeeded(master0, master1_ctx, cache);

        WriteMasterOutputs(master0, offsets, cache);
        WriteMasterOutputs(master1_ctx, offsets, cache);

        if (++axis_error_log_counter >= kAxisErrorLogPeriodCycles) {
            axis_error_log_counter = 0;
            if (HasAnyFaultOrError(cache)) {
                PrintAxisErrorCodeLog(cache);
            }
        }

        if (++runtime_snapshot_counter >= kRuntimeSnapshotPeriodCycles) {
            runtime_snapshot_counter = 0;
            ++runtime_snapshot_index;
            PrintRuntimeSnapshot(master0, master1_ctx, offsets, runtime_snapshot_index);
        }

        SyncAndSendMaster(master0);
        SyncAndSendMaster(master1_ctx);

#ifdef MEASURE_PERF
        if (((cache.t_cur - cache.t_prev) > 1100000) || ((cache.t_cur - cache.t_prev) < 900000)) {
            time_log_flag = 1;
            printf("\nTimestamp diff: %" PRIu32 " ns\n\n", cache.t_cur - cache.t_prev);
        } else {
            time_log_flag = 0;
        }
        cache.t_prev = cache.t_cur;
#endif
    }
}

} // namespace igh_driver_internal
