#!/usr/bin/env python3
"""Read EtherCAT axis shared memory written by igh_driver."""

from __future__ import annotations

import argparse
import ctypes
import mmap
import os
import time
from typing import Iterator, Optional


REAL_SHM_NAME = "Ethercat_axis_real"
DESIRE_SHM_NAME = "Ethercat_axis_desire"
DEBUG_SHM_NAME = "Ethercat_axis_debug"
DEFAULT_AXIS_COUNT = 20
STATE_OPERATION_ENABLED = 0x27
DEBUG_MAGIC = 0x534D4D44
MONITOR_STATE_NAMES = {
    0: "PowerOff",
    1: "Enabling",
    2: "Armed",
    3: "Faulted",
}


class AxisWriteReg(ctypes.Structure):
    _fields_ = [
        ("ec_modestate", ctypes.c_uint8),
        ("ec_ctrstate", ctypes.c_uint8),
        ("axis_position", ctypes.c_int32),
        ("axis_velocity", ctypes.c_int32),
        ("axis_effort", ctypes.c_int32),
        ("axis_encoder_0", ctypes.c_int32),
        ("axis_encoder_1", ctypes.c_int32),
        ("axis_error_code", ctypes.c_uint16),
        ("axis_counter", ctypes.c_uint8),
        ("axis_checksum", ctypes.c_uint8),
    ]


class AxisReadReg(ctypes.Structure):
    _fields_ = [
        ("ec_mode", ctypes.c_uint8),
        ("ec_ctrword", ctypes.c_uint8),
        ("axis_position", ctypes.c_int32),
        ("axis_velocity", ctypes.c_int32),
        ("axis_effort", ctypes.c_int32),
        ("axis_counter", ctypes.c_uint8),
        ("axis_checksum", ctypes.c_uint8),
    ]


class SharedMotorMonitorDebug(ctypes.Structure):
    _fields_ = [
        ("magic", ctypes.c_uint32),
        ("monitor_state", ctypes.c_uint8),
        ("force_shutdown", ctypes.c_uint8),
        ("armed_latched", ctypes.c_uint8),
        ("seen_poweroff_after_fault", ctypes.c_uint8),
        ("ec_poweron", ctypes.c_uint8),
        ("power_request_allowed", ctypes.c_uint8),
        ("all_20_enabled", ctypes.c_uint8),
        ("shared_bad", ctypes.c_uint8),
        ("shared_bad_axis", ctypes.c_uint8),
        ("shared_bad_state", ctypes.c_uint8),
        ("any_axis_fault", ctypes.c_uint8),
        ("mode_switch_bypass", ctypes.c_uint8),
        ("update_counter", ctypes.c_uint32),
    ]


def make_app_write_reg(axis_slots: int) -> type[ctypes.Structure]:
    class AppWriteReg(ctypes.Structure):
        _fields_ = [
            ("ec_powerstate", ctypes.c_uint8),
            ("axis_state", AxisWriteReg * axis_slots),
        ]

    return AppWriteReg


def make_app_read_reg(axis_slots: int, has_axis_io: bool) -> type[ctypes.Structure]:
    fields = [
        ("ec_poweron", ctypes.c_uint8),
        ("axis_ctr", AxisReadReg * axis_slots),
    ]
    if has_axis_io:
        fields.append(("ec_axis_io", ctypes.c_uint8 * 16))

    class AppReadReg(ctypes.Structure):
        _fields_ = fields

    return AppReadReg


def shm_path(name: str) -> str:
    return os.path.join("/dev/shm", name)


def get_shm_size(name: str) -> int:
    path = shm_path(name)
    try:
        return os.stat(path).st_size
    except FileNotFoundError as exc:
        raise SystemExit(
            f"Cannot open {path}. Start igh_driver first, or check the shared memory name."
        ) from exc


def infer_real_axis_slots(real_size: int) -> int:
    for axis_slots in range(1, 65):
        if ctypes.sizeof(make_app_write_reg(axis_slots)) == real_size:
            return axis_slots
    raise SystemExit(
        f"Cannot infer real axis slot count from {shm_path(REAL_SHM_NAME)} size {real_size} bytes."
    )


def infer_desire_layout(desire_size: int) -> tuple[int, bool]:
    for axis_slots in range(1, 65):
        for has_axis_io in (False, True):
            if ctypes.sizeof(make_app_read_reg(axis_slots, has_axis_io)) == desire_size:
                return axis_slots, has_axis_io
    raise SystemExit(
        f"Cannot infer desire layout from {shm_path(DESIRE_SHM_NAME)} size {desire_size} bytes."
    )


def read_struct(name: str, struct_type: type[ctypes.Structure]) -> ctypes.Structure:
    path = shm_path(name)
    size = ctypes.sizeof(struct_type)

    try:
        fd = os.open(path, os.O_RDONLY)
    except FileNotFoundError as exc:
        raise SystemExit(
            f"Cannot open {path}. Start igh_driver first, or check the shared memory name."
        ) from exc

    try:
        stat = os.fstat(fd)
        if stat.st_size < size:
            raise SystemExit(f"{path} is too small: {stat.st_size} bytes, expected at least {size}.")

        with mmap.mmap(fd, size, access=mmap.ACCESS_READ) as mapped:
            return struct_type.from_buffer_copy(mapped[:size])
    finally:
        os.close(fd)


def try_read_struct(name: str, struct_type: type[ctypes.Structure]) -> Optional[ctypes.Structure]:
    path = shm_path(name)
    size = ctypes.sizeof(struct_type)

    try:
        fd = os.open(path, os.O_RDONLY)
    except FileNotFoundError:
        return None

    try:
        stat = os.fstat(fd)
        if stat.st_size < size:
            return None

        with mmap.mmap(fd, size, access=mmap.ACCESS_READ) as mapped:
            return struct_type.from_buffer_copy(mapped[:size])
    finally:
        os.close(fd)


def iter_samples(interval: float | None) -> Iterator[None]:
    yield
    while interval is not None:
        time.sleep(interval)
        yield


def print_snapshot(axis_count: int) -> None:
    real_slots = infer_real_axis_slots(get_shm_size(REAL_SHM_NAME))
    desire_slots, desire_has_axis_io = infer_desire_layout(get_shm_size(DESIRE_SHM_NAME))
    AppWriteReg = make_app_write_reg(real_slots)
    AppReadReg = make_app_read_reg(desire_slots, desire_has_axis_io)
    real = read_struct(REAL_SHM_NAME, AppWriteReg)
    desire = read_struct(DESIRE_SHM_NAME, AppReadReg)
    debug = try_read_struct(DEBUG_SHM_NAME, SharedMotorMonitorDebug)
    printable_axis_count = min(axis_count, real_slots)

    print(
        f"ec_poweron:{desire.ec_poweron} "
        f"ec_powerstate:{real.ec_powerstate} "
        f"real_slots:{real_slots} "
        f"desire_slots:{desire_slots} "
        f"desire_axis_io:{int(desire_has_axis_io)} "
        f"normal_state:39(0x27)"
    )

    if debug is not None and debug.magic == DEBUG_MAGIC:
        monitor_state_name = MONITOR_STATE_NAMES.get(debug.monitor_state, "Unknown")
        print(
            f"monitor_state:{monitor_state_name}({debug.monitor_state}) "
            f"force_shutdown:{debug.force_shutdown} "
            f"armed_latched:{debug.armed_latched} "
            f"seen_poweroff_after_fault:{debug.seen_poweroff_after_fault} "
            f"mode_switch_bypass:{debug.mode_switch_bypass} "
            f"power_req:{debug.power_request_allowed} "
            f"all_20_enabled:{debug.all_20_enabled} "
            f"shared_bad:{debug.shared_bad} "
            f"shared_bad_axis:{debug.shared_bad_axis} "
            f"shared_bad_state:{debug.shared_bad_state}(0x{debug.shared_bad_state:02x}) "
            f"any_axis_fault:{debug.any_axis_fault} "
            f"updates:{debug.update_counter}"
        )
    else:
        print("monitor_state:unavailable debug_shm:0")

    first_bad = None
    for index in range(min(DEFAULT_AXIS_COUNT, real_slots)):
        state = real.axis_state[index].ec_ctrstate
        if state != STATE_OPERATION_ENABLED:
            first_bad = (index, state)
            break

    if first_bad is None:
        print("shared_20_all_enabled:1 first_bad:none")
    else:
        print(f"shared_20_all_enabled:0 first_bad:{first_bad[0]} state:{first_bad[1]}(0x{first_bad[1]:02x})")

    print("idx state(hex) ok mode(hex) position velocity effort err")

    for index in range(printable_axis_count):
        axis = real.axis_state[index]
        state = axis.ec_ctrstate
        ok = "OK" if state == STATE_OPERATION_ENABLED else "BAD"
        print(
            f"{index:02d}  {state:3d}(0x{state:02x}) {ok:3s} "
            f"0x{axis.ec_modestate:02x} "
            f"{axis.axis_position:11d} "
            f"{axis.axis_velocity:9d} "
            f"{axis.axis_effort:7d} "
            f"0x{axis.axis_error_code:04x}"
        )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Print Ethercat_axis_real.axis_state and Ethercat_axis_desire.ec_poweron."
    )
    parser.add_argument(
        "-n",
        "--axis-count",
        type=int,
        default=DEFAULT_AXIS_COUNT,
        help="number of axis_state entries to print, default: 20",
    )
    parser.add_argument(
        "-w",
        "--watch",
        nargs="?",
        const=0.2,
        type=float,
        help="refresh continuously; optional interval seconds, default: 0.2",
    )
    args = parser.parse_args()

    if args.axis_count < 1 or args.axis_count > 23:
        raise SystemExit("--axis-count must be between 1 and 23")

    first = True
    for _ in iter_samples(args.watch):
        if not first:
            print()
        first = False
        print_snapshot(args.axis_count)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
